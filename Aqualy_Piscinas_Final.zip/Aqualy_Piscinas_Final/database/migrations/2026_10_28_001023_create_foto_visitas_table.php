<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('foto_visitas', function (Blueprint $table) {
            $table->id();

            $table->foreignId('visita_id')
                ->constrained('visitas')
                ->cascadeOnDelete();

            $table->string('caminho');
            $table->string('legenda')->nullable();

            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('foto_visitas');
    }
};
