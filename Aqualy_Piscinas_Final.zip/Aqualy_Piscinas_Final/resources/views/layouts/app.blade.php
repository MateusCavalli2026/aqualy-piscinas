<!doctype html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Aqualy Piscinas — gestão de clientes, visitas técnicas e manutenção de piscinas.">
    <title>{{ $title ?? 'Aqualy Piscinas' }}</title>
    <link rel="icon" type="image/svg+xml" href="{{ asset('favicon.svg') }}">
    <link rel="stylesheet" href="{{ asset('css/aqualy.css') }}">
    @stack('styles')
</head>
<body>
    <div class="app-shell">
        <aside class="sidebar" id="sidebar">
            <div class="brand-lockup">
                <span class="brand-mark" aria-hidden="true"><span></span><span></span><span></span></span>
                <div><strong>aqualy</strong><small>PISCINAS</small></div>
            </div>
            <p class="sidebar-label">PAINEL DE OPERAÇÕES</p>
            <nav class="main-nav" aria-label="Navegação principal">
                <a class="nav-link {{ request()->routeIs('dashboard') ? 'active' : '' }}" href="{{ route('dashboard') }}"><span class="nav-icon">⌂</span><span>Visão geral</span></a>
                <a class="nav-link {{ request()->routeIs('clientes.*') ? 'active' : '' }}" href="{{ route('clientes.index') }}"><span class="nav-icon">♧</span><span>Clientes</span><span class="nav-count">{{ \App\Models\Cliente::count() }}</span></a>
                <a class="nav-link {{ request()->routeIs('visitas.*') ? 'active' : '' }}" href="{{ route('visitas.index') }}"><span class="nav-icon">▣</span><span>Visitas técnicas</span></a>
            </nav>
            <div class="sidebar-bottom">
                <div class="side-tip"><span>✦</span><div><b>Qualidade em cada visita</b><small>Registre tudo. Entregue confiança.</small></div></div>
                <div class="sidebar-footer"><span class="online-dot"></span> Sistema operacional</div>
            </div>
        </aside>

        <div class="main-area">
            <header class="topbar">
                <button class="menu-toggle" id="menuToggle" type="button" aria-label="Abrir menu">☰</button>
                <div class="topbar-context"><span class="context-dot"></span><span>Operação</span><b>/</b><strong>{{ $section ?? 'Visão geral' }}</strong></div>
                <div class="topbar-actions"><span class="today-label">{{ now()->translatedFormat('d \d\e F \d\e Y') }}</span><div class="profile-chip"><span>AP</span><div><b>Aqualy Piscinas</b><small>Equipe de manutenção</small></div></div></div>
            </header>
            <main class="page-content">
                @if(session('sucesso'))<div class="flash flash-success"><span>✓</span>{{ session('sucesso') }}<button type="button" data-dismiss>×</button></div>@endif
                @if($errors->any())<div class="flash flash-error"><span>!</span><div>@foreach($errors->all() as $erro)<p>{{ $erro }}</p>@endforeach</div><button type="button" data-dismiss>×</button></div>@endif
                @yield('content')
            </main>
            <footer class="page-footer"><span>© {{ date('Y') }} Aqualy Piscinas</span><span>Manutenção que transforma água em bem-estar.</span></footer>
        </div>
    </div>
    <div class="mobile-scrim" id="mobileScrim"></div>
    <script src="{{ asset('js/aqualy.js') }}"></script>
    @stack('scripts')
</body>
</html>
