@extends('layouts.app', ['title' => 'Visão geral — Aqualy Piscinas', 'section' => 'Visão geral'])

@section('content')
<div class="page-heading dashboard-heading"><div><p class="eyebrow">TERÇA-FEIRA · CENTRO DE OPERAÇÕES</p><h1>Bom trabalho, equipe <em>Aqualy.</em></h1><p class="heading-subtitle">Acompanhe seus clientes, organize as visitas e mantenha cada piscina no ponto.</p></div><a class="button button-primary" href="{{ route('visitas.index') }}#nova-visita"><span>＋</span> Agendar visita</a></div>

<div class="stats-grid">
    <article class="stat-card stat-blue"><div class="stat-icon">♧</div><div><span>Clientes ativos</span><strong>{{ $totalClientes }}</strong><small>base cadastrada</small></div><div class="stat-line"></div></article>
    <article class="stat-card stat-aqua"><div class="stat-icon">▣</div><div><span>Visitas agendadas</span><strong>{{ $visitasAgendadas }}</strong><small>próximos atendimentos</small></div><div class="stat-line"></div></article>
    <article class="stat-card stat-sun"><div class="stat-icon">✓</div><div><span>Serviços realizados</span><strong>{{ $visitasRealizadas }}</strong><small>histórico concluído</small></div><div class="stat-line"></div></article>
    <article class="stat-card stat-lilac"><div class="stat-icon">▧</div><div><span>Fotos registradas</span><strong>{{ $totalFotos }}</strong><small>evidências de serviço</small></div><div class="stat-line"></div></article>
</div>

<div class="dashboard-grid">
    <section class="panel upcoming-panel"><div class="panel-heading"><div><p class="eyebrow">AGENDA</p><h2>Próximas visitas</h2></div><a class="text-link" href="{{ route('visitas.index') }}">Ver agenda <span>→</span></a></div>
        @forelse($proximasVisitas as $visita)
            <div class="agenda-row"><div class="date-tile"><b>{{ $visita->data_visita->format('d') }}</b><span>{{ $visita->data_visita->translatedFormat('M') }}</span></div><div class="agenda-info"><strong>{{ $visita->titulo }}</strong><span>{{ $visita->cliente->nome }} @if($visita->hora_visita) · {{ substr($visita->hora_visita, 0, 5) }} @endif</span></div><span class="status-pill status-{{ $visita->status }}">{{ ucfirst($visita->status) }}</span></div>
        @empty
            <div class="empty-state compact"><span>◌</span><div><strong>Agenda livre por enquanto</strong><p>Cadastre uma visita para começar a organizar sua operação.</p></div><a class="button button-secondary" href="{{ route('visitas.index') }}#nova-visita">Criar visita</a></div>
        @endforelse
    </section>
    <section class="panel quick-panel"><div class="panel-heading"><div><p class="eyebrow">ATALHOS</p><h2>Acesso rápido</h2></div></div><div class="quick-links"><a href="{{ route('clientes.index') }}#novo-cliente"><span class="quick-icon blue">＋</span><div><b>Novo cliente</b><small>Cadastre um contato</small></div><i>→</i></a><a href="{{ route('visitas.index') }}#nova-visita"><span class="quick-icon aqua">＋</span><div><b>Nova visita técnica</b><small>Programe um atendimento</small></div><i>→</i></a><a href="{{ route('visitas.index') }}#historico"><span class="quick-icon sun">▣</span><div><b>Relatórios de serviço</b><small>Veja fotos e registros</small></div><i>→</i></a></div></section>
</div>

    <section class="panel recent-panel"><div class="panel-heading"><div><p class="eyebrow">ATIVIDADE RECENTE</p><h2>Últimos registros</h2></div><a class="text-link" href="{{ route('visitas.index') }}#historico">Ver todos <span>→</span></a></div><div class="table-wrap"><table class="data-table"><thead><tr><th>Serviço</th><th>Cliente</th><th>Data</th><th>Status</th></tr></thead><tbody>@forelse($ultimasVisitas as $visita)<tr><td><strong>{{ $visita->titulo }}</strong><small>{{ \Illuminate\Support\Str::limit($visita->descricao ?? 'Registro de atendimento Aqualy', 55) }}</small></td><td><span class="client-cell"><span>{{ strtoupper(substr($visita->cliente->nome, 0, 1)) }}</span>{{ $visita->cliente->nome }}</span></td><td>{{ $visita->data_visita->format('d/m/Y') }}</td><td><span class="status-pill status-{{ $visita->status }}">{{ ucfirst($visita->status) }}</span></td></tr>@empty<tr><td colspan="4"><div class="empty-table">Ainda não há registros de visitas.</div></td></tr>@endforelse</tbody></table></div></section>
@endsection
