(() => {
  const toggle = document.querySelector('#menuToggle');
  const sidebar = document.querySelector('#sidebar');
  const scrim = document.querySelector('#mobileScrim');
  const closeMenu = () => { sidebar?.classList.remove('is-open'); scrim?.classList.remove('is-visible'); };
  toggle?.addEventListener('click', () => { sidebar?.classList.toggle('is-open'); scrim?.classList.toggle('is-visible'); });
  scrim?.addEventListener('click', closeMenu);
  document.querySelectorAll('.main-nav a').forEach((link) => link.addEventListener('click', closeMenu));
  document.querySelectorAll('[data-dismiss]').forEach((button) => button.addEventListener('click', () => button.closest('.flash')?.remove()));
  document.querySelectorAll('input[type=file]').forEach((input) => input.addEventListener('change', () => {
    const label = input.closest('.upload-label');
    if (label && input.files.length) label.querySelector('span').textContent = `${input.files.length} arquivo(s)`;
  }));
})();
