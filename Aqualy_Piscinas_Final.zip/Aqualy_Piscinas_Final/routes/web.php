<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ClienteController;
use App\Http\Controllers\VisitaController;
use App\Http\Controllers\DashboardController;

Route::get('/', [DashboardController::class, 'index'])->name('dashboard');

// Rotas de clientes
Route::get('/clientes', [ClienteController::class, 'index'])
    ->name('clientes.index');

Route::post('/clientes', [ClienteController::class, 'store'])
    ->name('clientes.store');

Route::delete('/clientes/{cliente}', [ClienteController::class, 'destroy'])
    ->name('clientes.destroy');

// Rotas de visitas
Route::get('/visitas', [VisitaController::class, 'index'])
    ->name('visitas.index');

Route::post('/visitas', [VisitaController::class, 'store'])
    ->name('visitas.store');

Route::delete('/visitas/{visita}', [VisitaController::class, 'destroy'])
    ->name('visitas.destroy');


use App\Http\Controllers\FotoVisitaController;

// Rotas de fotos das visitas
Route::post('/visitas/{visita}/fotos', [FotoVisitaController::class, 'store'])
    ->name('visitas.fotos.store');

Route::delete('/fotos-visitas/{fotoVisita}', [FotoVisitaController::class, 'destroy'])
    ->name('visitas.fotos.destroy');
    
