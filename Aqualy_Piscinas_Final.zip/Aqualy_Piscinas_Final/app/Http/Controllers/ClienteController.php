<?php

namespace App\Http\Controllers;

use App\Models\Cliente;
use Illuminate\Http\Request;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Storage;
use Illuminate\View\View;

class ClienteController extends Controller
{
    public function index(Request $request): View
    {
        $busca = trim($request->string('busca')->toString());
        $clientes = Cliente::withCount('visitas')
            ->when($busca, function ($query) use ($busca) {
                $query->where(function ($subquery) use ($busca) {
                    $subquery->where('nome', 'like', "%{$busca}%")
                        ->orWhere('empresa', 'like', "%{$busca}%")
                        ->orWhere('telefone', 'like', "%{$busca}%")
                        ->orWhere('email', 'like', "%{$busca}%");
                });
            })
            ->orderBy('nome')
            ->get();

        return view('clientes.index', compact('clientes', 'busca'));
    }

    public function store(Request $request): RedirectResponse
    {
        $dados = $request->validate([
            'nome' => 'required|string|max:255',
            'empresa' => 'nullable|string|max:255',
            'email' => 'nullable|email|max:255',
            'telefone' => 'nullable|string|max:30',
            'endereco' => 'nullable|string|max:255',
            'observacoes' => 'nullable|string',
        ]);

        Cliente::create($dados);

        return redirect()
            ->route('clientes.index')
            ->with('sucesso', 'Cliente cadastrado com sucesso!');
    }

    public function destroy(Cliente $cliente): RedirectResponse
    {
        $cliente->load('visitas.fotos');
        foreach ($cliente->visitas as $visita) {
            foreach ($visita->fotos as $foto) {
                Storage::disk('public')->delete($foto->caminho);
            }
        }
        $cliente->delete();

        return redirect()
            ->route('clientes.index')
            ->with('sucesso', 'Cliente excluído com sucesso!');
    }
}
