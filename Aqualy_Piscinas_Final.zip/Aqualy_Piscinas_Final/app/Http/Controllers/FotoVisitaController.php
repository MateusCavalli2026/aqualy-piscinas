<?php

namespace App\Http\Controllers;

use App\Models\FotoVisita;
use App\Models\Visita;
use Illuminate\Http\Request;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Storage;

class FotoVisitaController extends Controller
{
    public function store(Request $request, Visita $visita): RedirectResponse
    {
        $dados = $request->validate([
            'fotos' => 'required|array|min:1',
            'fotos.*' => 'required|image|mimes:jpg,jpeg,png,webp|max:5120',
            'legendas' => 'nullable|array',
            'legendas.*' => 'nullable|string|max:255',
        ]);

        foreach ($request->file('fotos') as $indice => $foto) {
            $caminho = $foto->store('fotos-visitas', 'public');

            $visita->fotos()->create([
                'caminho' => $caminho,
                'legenda' => $request->input("legendas.$indice"),
            ]);
        }

        return redirect()
            ->route('visitas.index')
            ->with('sucesso', 'Fotos anexadas à visita com sucesso!');
    }

    public function destroy(FotoVisita $fotoVisita): RedirectResponse
    {
        Storage::disk('public')->delete($fotoVisita->caminho);
        $fotoVisita->delete();

        return redirect()
            ->route('visitas.index')
            ->with('sucesso', 'Foto excluída com sucesso!');
    }
}
