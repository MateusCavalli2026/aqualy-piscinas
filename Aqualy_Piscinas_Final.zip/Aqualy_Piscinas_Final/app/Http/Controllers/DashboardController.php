<?php

namespace App\Http\Controllers;

use App\Models\Cliente;
use App\Models\FotoVisita;
use App\Models\Visita;
use Illuminate\View\View;

class DashboardController extends Controller
{
    public function index(): View
    {
        $totalClientes = Cliente::count();
        $totalVisitas = Visita::count();
        $visitasAgendadas = Visita::where('status', 'agendada')->count();
        $visitasRealizadas = Visita::where('status', 'realizada')->count();
        $totalFotos = FotoVisita::count();
        $proximasVisitas = Visita::with('cliente')
            ->where('status', 'agendada')
            ->whereDate('data_visita', '>=', today())
            ->orderBy('data_visita')
            ->orderBy('hora_visita')
            ->limit(5)
            ->get();
        $ultimasVisitas = Visita::with('cliente')
            ->latest('data_visita')
            ->latest('created_at')
            ->limit(5)
            ->get();

        return view('dashboard', compact(
            'totalClientes',
            'totalVisitas',
            'visitasAgendadas',
            'visitasRealizadas',
            'totalFotos',
            'proximasVisitas',
            'ultimasVisitas',
        ));
    }
}
