<?php

namespace App\Http\Controllers;

use App\Models\Cliente;
use App\Models\Visita;
use Illuminate\Http\Request;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Storage;
use Illuminate\View\View;

class VisitaController extends Controller
{
    public function index(): View
    {
        $visitas = Visita::with(['cliente', 'fotos'])
            ->orderByDesc('data_visita')
            ->orderByDesc('hora_visita')
            ->get();

        $clientes = Cliente::orderBy('nome')->get();

        return view('visitas.index', compact('visitas', 'clientes'));
    }

    public function store(Request $request): RedirectResponse
    {
        $dados = $request->validate([
            'cliente_id' => 'required|exists:clientes,id',
            'data_visita' => 'required|date',
            'hora_visita' => 'nullable|date_format:H:i',
            'titulo' => 'required|string|max:255',
            'descricao' => 'nullable|string',
            'status' => 'required|in:agendada,realizada,cancelada',
            'observacoes' => 'nullable|string',
        ]);

        Visita::create($dados);

        return redirect()
            ->route('visitas.index')
            ->with('sucesso', 'Visita cadastrada com sucesso!');
    }

    public function destroy(Visita $visita): RedirectResponse
    {
        $visita->load('fotos');
        foreach ($visita->fotos as $foto) {
            Storage::disk('public')->delete($foto->caminho);
        }
        $visita->delete();

        return redirect()
            ->route('visitas.index')
            ->with('sucesso', 'Visita excluída com sucesso!');
    }
}
