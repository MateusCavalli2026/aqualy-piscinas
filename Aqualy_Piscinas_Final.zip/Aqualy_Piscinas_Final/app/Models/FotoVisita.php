<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class FotoVisita extends Model
{
    use HasFactory;

    protected $fillable = [
        'visita_id',
        'caminho',
        'legenda',
    ];

    public function visita(): BelongsTo
    {
        return $this->belongsTo(Visita::class);
    }
}
