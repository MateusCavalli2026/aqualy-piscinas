<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Visita extends Model
{
    use HasFactory;

    protected $fillable = [
        'cliente_id',
        'data_visita',
        'hora_visita',
        'titulo',
        'descricao',
        'status',
        'observacoes',
    ];

    protected function casts(): array
    {
        return [
            'data_visita' => 'date',
        ];
    }

    public function cliente(): BelongsTo
    {
        return $this->belongsTo(Cliente::class);
    }

    public function fotos(): HasMany
    {
        return $this->hasMany(FotoVisita::class);
    }
}
