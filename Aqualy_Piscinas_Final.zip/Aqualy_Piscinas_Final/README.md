# Aqualy Piscinas — Gestão de visitas técnicas

Sistema acadêmico em **Laravel 13 + PHP 8.3 + SQLite** para organizar clientes, agenda de manutenção e registros fotográficos da Aqualy Piscinas.

## O que foi entregue

- Dashboard com indicadores de clientes, visitas agendadas, serviços realizados e fotos.
- Cadastro de clientes com empresa, telefone, e-mail, endereço e observações.
- Busca por nome, empresa, telefone ou e-mail.
- Agenda de visitas técnicas com data, horário, tipo de serviço, status e descrição.
- Histórico de atendimentos com status visual: agendada, realizada ou cancelada.
- Upload de múltiplas fotos por visita, com validação de imagem de até 5 MB.
- Exclusão de visitas/clientes com limpeza dos arquivos de fotos associados.
- Layout responsivo, identidade visual própria e navegação em português.
- Proteção CSRF nas operações de formulário e validações no backend.
- Banco SQLite e migrations para instalação simples.

## Requisitos

- PHP 8.3 ou superior
- Composer 2
- Extensão PHP SQLite habilitada

## Instalação

```bash
composer install
cp .env.example .env
php artisan key:generate
mkdir -p database
touch database/database.sqlite
php artisan migrate
php artisan storage:link
php artisan serve
```

Acesse `http://127.0.0.1:8000`.

Para rodar os testes:

```bash
php artisan test
```

## Estrutura principal

- `app/Http/Controllers/DashboardController.php`: indicadores e agenda resumida.
- `app/Http/Controllers/ClienteController.php`: cadastro, busca e exclusão de clientes.
- `app/Http/Controllers/VisitaController.php`: agenda e histórico de visitas.
- `app/Http/Controllers/FotoVisitaController.php`: upload e remoção de fotos.
- `resources/views/layouts/app.blade.php`: layout compartilhado e navegação.
- `resources/views/dashboard.blade.php`: painel inicial.
- `resources/views/clientes/index.blade.php`: relacionamento de clientes.
- `resources/views/visitas/index.blade.php`: rotina de campo e fotos.
- `public/css/aqualy.css`: identidade visual responsiva.
- `public/js/aqualy.js`: menu mobile, alertas e interação de upload.
- `database/migrations/`: estrutura de clientes, visitas, fotos e tabelas padrão.

## Roteiro para apresentar no curso

1. Abra o dashboard e explique os indicadores operacionais.
2. Cadastre um cliente em **Clientes**.
3. Crie uma visita técnica em **Visitas técnicas**.
4. Abra o item de fotos e anexe imagens de exemplo.
5. Mostre o histórico, os status e a exclusão segura de registros.

O sistema é uma ferramenta de gestão interna para demonstração acadêmica. Para uso comercial em produção, ainda seriam recomendados autenticação de equipe, permissões por usuário, backups, política de privacidade e hospedagem com HTTPS.
