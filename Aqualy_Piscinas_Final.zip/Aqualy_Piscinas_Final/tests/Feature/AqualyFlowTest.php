<?php

namespace Tests\Feature;

use App\Models\Cliente;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class AqualyFlowTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        $this->withoutMiddleware();
    }

    public function test_a_client_can_be_created_from_the_clients_page(): void
    {
        $response = $this->post(route('clientes.store'), [
            'nome' => 'Mariana Oliveira',
            'empresa' => 'Residencial Azul',
            'telefone' => '(11) 99999-9999',
            'email' => 'mariana@example.test',
            'endereco' => 'Rua das Palmeiras, 80',
        ]);

        $response->assertRedirect(route('clientes.index'));
        $this->assertDatabaseHas('clientes', ['nome' => 'Mariana Oliveira', 'empresa' => 'Residencial Azul']);
    }

    public function test_a_visit_requires_a_valid_client_and_can_be_scheduled(): void
    {
        $cliente = Cliente::create(['nome' => 'Cliente de Teste']);

        $response = $this->post(route('visitas.store'), [
            'cliente_id' => $cliente->id,
            'data_visita' => '2026-10-30',
            'hora_visita' => '09:30',
            'titulo' => 'Limpeza e análise de pH',
            'status' => 'agendada',
            'descricao' => 'Revisão completa da água e dos equipamentos.',
        ]);

        $response->assertRedirect(route('visitas.index'));
        $this->assertDatabaseHas('visitas', ['cliente_id' => $cliente->id, 'status' => 'agendada']);
    }
}
